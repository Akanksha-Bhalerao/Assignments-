import streamlit as st
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score

st.title(" Titanic Survival Prediction using Logistic Regression")

# Load dataset
st.subheader("Dataset Overview")
train_data = pd.read_csv("Titanic_train.csv")
st.write(train_data.head())

# Preprocess data
st.subheader("Data Preprocessing")
data = train_data.copy()

# Fill missing values
data['Age'].fillna(data['Age'].median(), inplace=True)
data['Embarked'].fillna(data['Embarked'].mode()[0], inplace=True)

# Encode categorical variables
label = LabelEncoder()
data['Sex'] = label.fit_transform(data['Sex'])
data['Embarked'] = label.fit_transform(data['Embarked'])

# Select features and target
X = data[['Pclass', 'Sex', 'Age', 'SibSp', 'Parch', 'Fare', 'Embarked']]
y = data['Survived']

# Split and train model
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
model = LogisticRegression(max_iter=200)
model.fit(X_train, y_train)

# Evaluate model
y_pred = model.predict(X_test)
acc = accuracy_score(y_test, y_pred)
st.write(f" Model trained successfully with accuracy: **{acc:.2f}**")

st.divider()

# User input for prediction
st.subheader(" Predict Passenger Survival")

pclass = st.selectbox("Passenger Class (1 = 1st, 2 = 2nd, 3 = 3rd)", [1, 2, 3])
sex = st.selectbox("Sex", ["male", "female"])
age = st.slider("Age", 1, 80, 25)
sibsp = st.number_input("Number of Siblings/Spouses Aboard", 0, 8, 0)
parch = st.number_input("Number of Parents/Children Aboard", 0, 6, 0)
fare = st.number_input("Fare", 0.0, 600.0, 32.0)
embarked = st.selectbox("Port of Embarkation", ["C", "Q", "S"])

# Encode input
sex_num = 1 if sex == "male" else 0
embarked_num = {"C": 0, "Q": 1, "S": 2}[embarked]

# Create input DataFrame
user_input = np.array([[pclass, sex_num, age, sibsp, parch, fare, embarked_num]])
prediction = model.predict(user_input)

if st.button("Predict"):
    if prediction[0] == 1:
        st.success(" Passenger Survived!")
    else:
        st.error(" Passenger Did Not Survive.")

st.divider()
st.caption("Developed by Aakanksha Arvind Bhalerao  | Data Science Assignment")
